/**
 * JSON to XML jQuery plugin. Provides quick way to convert JSON object to XML 
 * string. To some extent, allows control over XML output.
 * Just as jQuery itself, this plugin is released under both MIT & GPL licences.
 * 
 * @version 1.02
 * @author Micha³ Korecki, www.michalkorecki.com
 */
(function($) {
    $.form2xml = function(data) {
        var xml = '<?xml version="1.0" encoding="UTF-8"?>';
        xml += '<order>';

        for(var pair of data.entries()) {
            var key = pair[0];
            var value = pair[1];

            xml += '<' + key + '>' + value + '</' + key + '>';
        }

        xml += '</order>';
        return xml;
    }
})(jQuery);