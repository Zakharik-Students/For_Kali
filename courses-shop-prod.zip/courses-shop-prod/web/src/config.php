<?php

$servername = "db";
$username = "root";
$password = "Phaixe6Ait";
$dbname = "Task";
