<?php

include("config.php");

if (isset($_GET["orderID"]) && !empty($_GET["orderID"])) {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (strpos( $_GET['orderID'],';')) {
        echo "Hacking Attempt!";
        die();
    }

    $sql = "SELECT * FROM orders WHERE id=".$_GET['orderID'];

    $stmt = $conn->query($sql);
    $order = $stmt->fetch();

    if (empty($order)){
        header("Location: /index.php");
        echo "No such order!";
        die();
    }

?>
<!DOCTYPE html>
     
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/image.php?file=apple-touch-icon-57x57.png">
    <title>Recipt</title>
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Custom styles for this template -->
    <link href="./static/pricing.css" rel="stylesheet">
    <style type="text/css">/*.lleo_errorSelection *::-moz-selection,
        .lleo_errorSelection *::selection,
        .lleo_errorSelection *::-webkit-selection {
        background-color: red !important;
        color: #fff !important;;
        }*/
        #lleo_dialog,
        #lleo_dialog * {
        color: #000 !important;
        font: normal 13px Arial, Helvetica !important;
        line-height: 15px !important;
        margin: 0 !important;
        padding: 0 !important;
        background: none !important;
        border: none 0 !important;
        position: static !important;
        vertical-align: baseline !important;
        overflow: visible !important;
        width: auto !important;
        height: auto !important;
        max-width: none !important;
        max-height: none !important;
        float: none !important;
        visibility: visible !important;
        text-align: left !important;
        text-transform: none !important;
        border-collapse: separate !important;
        border-spacing: 2px !important;
        box-sizing: content-box !important;
        box-shadow: none !important;
        opacity: 1 !important;
        text-shadow: none !important;
        letter-spacing: normal !important;
        -webkit-filter: none !important;
        -moz-filter: none !important;
        filter: none !important;
        }
        #lleo_dialog *:before,
        #lleo_dialog *:after {
        content: '';
        }
        #lleo_dialog iframe {
        height: 0 !important;
        width: 0 !important;
        }
        #lleo_dialog {
        position: absolute !important;
        background: #fff !important;
        border: solid 1px #ccc !important;
        padding: 7px 0 0 !important;
        left: -999px;
        top: -999px;
        width: 440px !important;
        overflow: hidden;
        display: block !important;
        z-index: 999999999 !important;
        box-shadow: 8px 16px 30px rgba(0, 0, 0, 0.16) !important;
        border-radius: 3px !important;
        opacity: 0 !important;
        -webkit-transform: translateY(15px);
        -moz-transform: translateY(15px);
        -ms-transform: translateY(15px);
        -o-transform: translateY(15px);
        transform: translateY(15px);
        }
        #lleo_dialog.lleo_show_small {
        width: 150px !important;
        }
        #lleo_dialog.lleo_show {
        opacity: 1 !important;
        -webkit-transform: translateY(0);
        -moz-transform: translateY(0);
        -ms-transform: translateY(0);
        -o-transform: translateY(0);
        transform: translateY(0);
        -webkit-transition: -webkit-transform 0.3s, opacity 0.3s !important;
        -moz-transition: -moz-transform 0.3s, opacity 0.3s !important;
        -ms-transition: -ms-transform 0.3s, opacity 0.3s !important;
        -o-transition: -o-transform 0.3s, opacity 0.3s !important;
        transition: transform 0.3s, opacity 0.3s !important;
        }
        #lleo_dialog.lleo_collapse {
        opacity: 0 !important;
        -webkit-transform: scale(0.25, 0.1) translate(-550px, 100px);
        -moz-transform: scale(0.25, 0.1) translate(-550px, 100px);
        -ms-transform: scale(0.25, 0.1) translate(-550px, 100px);
        -o-transform: scale(0.25, 0.1) translate(-550px, 100px);
        transform: scale(0.25, 0.1) translate(-550px, 100px);
        -webkit-transition: -webkit-transform 0.4s, opacity 0.4s !important;
        -moz-transition: -moz-transform 0.4s, opacity 0.4s !important;
        -ms-transition: -ms-transform 0.4s, opacity 0.4s !important;
        -o-transition: -o-transform 0.4s, opacity 0.4s !important;
        transition: transform 0.4s, opacity 0.4s !important;
        }
        #lleo_dialog input::-webkit-input-placeholder {
        color: #aaa !important;
        }
        #lleo_dialog .lleo_has_pic #lleo_word {
        margin-right: 80px !important;
        }
        #lleo_dialog #lleo_translationsContainer1 {
        position: relative !important;
        }
        #lleo_dialog #lleo_translationsContainer2 {
        padding: 7px 0 0 !important;
        vertical-align: middle !important;
        }
        #lleo_dialog #lleo_word {
        color: #000 !important;
        margin: 0 5px 2px 0 !important;
        /*float: left !important;*/
        }
        #lleo_dialog .lleo_has_sound #lleo_word {
        margin-left: 30px !important;
        }
        #lleo_dialog #lleo_text {
        font-weight: bold !important;
        color: #d56e00 !important;
        text-decoration: none !important;
        cursor: default !important;
        }
        /*
        #lleo_dialog #lleo_text.lleo_known {
        cursor: pointer !important;
        text-decoration: underline !important;
        }
        */
        /*#lleo_dialog #lleo_closeBtn {
        position: absolute !important;
        right: 6px !important;
        top: 5px !important;
        line-height: 1px !important;
        text-decoration: none !important;
        font-weight: bold !important;
        font-size: 0 !important;
        color: #aaa !important;
        display: block !important;
        z-index: 9999999999 !important;
        width: 7px !important;
        height: 7px !important;
        padding: 0 !important;
        margin: 0 !important;
        }*/
        #lleo_dialog #lleo_optionsBtn {
        position: absolute !important;
        right: 3px !important;
        top: 5px !important;
        line-height: 1px !important;
        text-decoration: none !important;
        font-weight: bold !important;
        font-size: 13px !important;
        color: #aaa !important;
        padding: 2px !important;
        display: none;
        }
        #lleo_dialog.lleo_optionsShown #lleo_optionsBtn {
        display: block !important;
        }
        #lleo_dialog #lleo_optionsBtn img {
        width: 12px !important;
        height: 12px !important;
        }
        #lleo_dialog #lleo_sound {
        float: left !important;
        width: 16px !important;
        height: 16px !important;
        margin-left: 9px !important;
        margin-right: 3px !important;
        background: 0 0 no-repeat !important;
        cursor: pointer !important;
        display: none !important;
        background: url("/image.php?file=volume.png") !important;
        }
        #lleo_dialog .lleo_has_sound #lleo_sound {
        display: block !important;
        }
        #lleo_dialog #lleo_soundWave {
        border: solid 5px #4495CC !important;
        border-radius: 5px !important;
        position: absolute !important;
        left: -5px !important;
        top: -5px !important;
        right: -5px !important;
        bottom: -5px !important;
        z-index: 0 !important;
        opacity: 0.9 !important;
        display: none !important;
        }
        #lleo_dialog #lleo_soundWave.lleo_beforePlaying {
        display: block !important;
        }
        #lleo_dialog #lleo_soundWave.lleo_playing {
        opacity: 0 !important;
        border-width: 20px !important;
        border-radius: 30px !important;
        -webkit-transform: scale(1.07,1.1) !important;
        -moz-transform: scale(1.07,1.1) !important;
        -ms-transform: scale(1.07,1.1) !important;
        transform: scale(1.07,1.1) !important;
        -webkit-transition: all 0.6s !important;
        -moz-transition: all 0.6s !important;
        -ms-transition: all 0.6s !important;
        transition: all 0.6s !important;
        }
        #lleo_dialog #lleo_picOuter {
        position: absolute !important;
        float: right !important;
        top: 4px;
        right: 5px;
        z-index: 9 !important;
        display: none !important;
        width: 100px !important;
        }
        #lleo_dialog.lleo_optionsShown #lleo_picOuter {
        right: 25px;
        }
        #lleo_dialog .lleo_has_pic #lleo_picOuter {
        display: block !important;
        }
        #lleo_dialog #lleo_picOuter:hover {
        width: auto !important;
        z-index: 11 !important;
        }
        #lleo_dialog #lleo_pic,
        #lleo_dialog #lleo_picBig {
        position: absolute !important;
        top: 0 !important;
        right: 0 !important;
        border: solid 2px #fff !important;
        -webkit-border-radius: 2px !important;
        -moz-border-radius: 2px !important;
        border-radius: 2px !important;
        z-index: 1 !important;
        }
        #lleo_dialog #lleo_pic {
        position: relative !important;
        border: none !important;
        width: 30px !important;
        }
        #lleo_dialog #lleo_picBig {
        box-shadow: -1px 2px 4px rgba(0,0,0,0.3);
        z-index: 2 !important;
        opacity: 0 !important;
        visibility: hidden !important;
        }
        #lleo_dialog #lleo_picOuter:hover #lleo_picBig {
        visibility: visible !important;
        opacity: 1 !important;
        -webkit-transition: opacity 0.3s !important;
        -webkit-transition-delay: 0.3s !important;
        }
        #lleo_dialog #lleo_transcription {
        margin: 0 80px 4px 31px !important;
        color: #aaaaaa !important;
        }
        #lleo_dialog .lleo_no_trans {
        color: #aaa !important;
        }
        #lleo_dialog .ll-translation-counter {
        float: right !important;
        font-size: 11px !important;
        color: #aaa !important;
        padding: 2px 2px 1px 10px !important;
        }
        #lleo_dialog .ll-translation-text {
        float: left !important;
        /*width: 80% !important;*/
        }
        #lleo_dialog #lleo_trans a {
        color: #3F669F !important;
        text-decoration: none !important;
        text-overflow: ellipsis !important;
        padding: 1px 4px !important;
        overflow: hidden !important;
        float: left !important;
        width: 320px !important;
        }
        #lleo_dialog .ll-translation-item {
        color: #3F669F !important;
        border: solid 1px #fff !important;
        padding: 3px !important;
        width: 100% !important;
        float: left !important;
        -moz-border-radius: 2px !important;
        -webkit-border-radius: 2px !important;
        border-radius: 2px !important;
        }
        #lleo_dialog .ll-translation-item:hover {
        border: solid 1px #9FC2C9 !important;
        background: #EDF4F6 !important;
        cursor: pointer !important;
        }
        #lleo_dialog .ll-translation-item:hover .ll-translation-counter {
        color: #83a0a6 !important;
        }
        #lleo_dialog .ll-translation-marker {
        background: url("/image.php?file=dot.png") !important;
        display: inline-block !important;
        width: 4px !important;
        height: 4px !important;
        margin: 7px 5px 2px 2px !important;
        float: left !important;
        }
        #lleo_dialog #lleo_icons {
        color: #aaa !important;
        font-size: 11px !important;
        background: #f8f8f8 !important;
        padding: 10px 10px 10px 16px !important;
        }
        #lleo_icons a {
        display: inline-block !important;
        width: 16px !important;
        height: 16px !important;
        margin: 0 10px -4px 3px !important;
        text-decoration: none !important;
        opacity: 0.5 !important;
        background: url("/image.php?file=pictures.png") !important;
        }
        #lleo_icons a:hover {
        opacity: 1 !important;
        }
        #lleo_icons a.lleo_google     {background-position:-34px 0 !important;}
        #lleo_icons a.lleo_multitran  {background-position:-64px 0 !important;}
        #lleo_icons a.lleo_lingvo     {background-position:-51px 0 !important; width: 12px !important;}
        #lleo_icons a.lleo_dict       {background-position:-17px 0 !important;}
        #lleo_icons a.lleo_linguee    {background-position:-81px 0 !important;}
        #lleo_icons a.lleo_michaelis  {background-position:-98px 0 !important;}
        #lleo_dialog #lleo_contextContainer {
        margin: 0 !important;
        padding: 3px 15px 8px 10px !important;
        background: #eee !important;
        background: -webkit-gradient(linear, left top, left bottom, from(#fff), to(#eee)) !important;
        background: -moz-linear-gradient(-90deg, #fff, #eee) !important;
        border-bottom: solid 1px #ddd !important;
        border-top-left-radius: 3px !important;
        border-top-right-radius: 3px !important;
        display: none !important;
        overflow: hidden !important;
        }
        #lleo_dialog .lleo_has_context #lleo_contextContainer {
        display: block !important;
        }
        #lleo_dialog #lleo_context {
        color: #444 !important;
        text-shadow: 1px 1px 0 #f4f4f4 !important;
        line-height: 12px !important;
        font-size: 11px !important;
        margin-left: 2px !important;
        }
        #lleo_dialog #lleo_context b {
        line-height: 12px !important;
        color: #000 !important;
        font-weight: bold !important;
        font-size: 11px !important;
        }
        /*#lleo_dialog #lleo_gBrand {
        color: #aaa !important;
        font-size: 10px !important;
        *//*padding-right: 52px !important;*//*
        padding-bottom: 14px !important;
        margin: -3px 4px 0 4px !important;
        background: left bottom url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADMAAAAPCAYAAABJGff8AAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAcVSURBVHja3FZrbFTHFT4z97W++/KatfHGNrFjMNjFLQ24iiVIFBzCD1SFqj/aRlCUCvjRKlVatUFJVJJGNKUtoRVqgZZWKWCVOEqKQxsaUoypaWzclNgGI9sLtndZv9beh/d133ems3ZAvKTGkfqnZ3U1d++9M+d88535zkGUUsjbpl/PgixiEEz05aHLIzsjo9cwIrrEy4EA7ypLm8rMAX2q850cYGMtmoD3tKOgYwF0QDAUjcFwwoLG33ih5hkZIJwFGjMA8QDRaQuCIzb0ZtbCMe00oCRbwUIwU7EHwo4jYFs6VASWPb3cv+yP7SfO9RCNNFIByLMpB+ybKIRoLgeXZhKweYrAfzP+1h3CABY90n/unafCwSs/xJK7BfMOzVZjq2w92WJlbhyzLeWSyXuCTXgMOKDsh2Dhlp9HoF57DdzTX4H4kteh5iHtzcRo8ph9XQ+DwZFGJME+RQYq5b/99HYLjNch7gi2t35roOONNQX+mh4kF7GnGDjnA70sgCe0eG+tIlcGX3F0wwtSN+gqBwJGvEXBumdVti9ImB/vNcT2DQHBGriMBkh17QZH7dFCgetBbIcywOa9Cm4QecSYx3dsV3Nz8x3Ytm7dio4fP063bNmC4HZ3BWrqpyN950d5qaDHVqeA2gZw8mLgRA9YBCKGDR+8zF2E3eg8AOdoCFuo+YpitswiboAFtwvNb/qcaTmy5+qg3XwjQi7YBLUjBCXsmmMSIbrZUJKHBWr2muZYRyo0vSfWV+YkyMx/YTTZPDyBCh68QeAP/ap5WuX4fobrsZvB3z7mgdyXmeRUvEjTjE5O8gIlBmDRC2LRKigp8QClOSguRfCj0PcZatejHYb455ORxPZaEf5azaOXRET3ahQWUQk9r+fMjgOHVFvg6FN11dhbGYB+SuBaVud8HhHvGx88tT6RMp6JzXxhmZ6OrqfGwC98KyZT0excfPqLgs8R5jwdhyMTr22Q8W+9Dn4kTLi/s3fi3RzfZOa2hJi3gZCKBLnIxzmK2Mb7GRgPEGqBIIpQXl4OevVGeEt+EqDI/7v3QxPaoGa38hxn1RRwP17sdk/lOP67KpiPDX6YXXuxj758I4rSdVUQKSuGnU4ZPMkk3u3Skjsmr3V/bKszPQW+qiZPcSWxcvHtlpJJ2wyLm6DMGm9g54V4ungltj+u9chHuhRytU0hz88Rz8Qqn1J3j/cwkzF4Q3AvedhWoiyneeCdFWy2hU1d28YU5nFJkMUDeN17681gqUPJqH6OvRYlKA34wXR5O1EytDkXy2xi5wgFSpDM0p2RiMBVAmcWpYAmppOrr03FbVxY2+T2+WFJpQ/S4YgWSV8PIsEp2jr7HsAmNl7m0BVp2rbrT0TTb4YNu83xKXXmFjPsjJzmPVUyO/B7BV8dcAV+luGUnwr1jWcS0Wh8bORryvC7Femh/qElmCwu5ZHopDZjTgC5QMJjBNRYkrQWOimw1Pp6KdMP4mCIy0QlqWM6Ebp+fna8+3uUcwcKS1e0SJA7ef1fred8n1NfKFwqFCMm12lKudDw8PulShbnCC0ux7TtG4US7PDghYGxlcltQEiMd5bt4pyB/VhwA5aKDW9p/QfVdStPg5mBYZ1a/0yYO/xg05US6lhOdNlOxus+ikw29s5mfjadQJ1ZBf5dXQFbH6lHG3wcOIwkPnyqjUYsPXvI70dviCKDL8o0MtS/WbeLXi1cvdrSxLTTMgykPcDV/bwq027o6vgKgdtbJ6L9tRK31oXhyQVJM2MmTW2tiuiJvyB1+jvUSD+NJX+fDtLkR13dZZNXT13NYv5iO//g5U1a/7o4gV8FLTgRiqu5M+nULpuQoyYTpFSWNiTT8HtVh59Ajx0cGNazlwfg8/rqXyqLH9pW4ghNfns2HiWZWNx2V6zqivWHvho50zKk902eRYQzTnwRL60ds2r8YfLuoE2+KepGk0DooYaFgMnrP9PNLLXVx830iGzMXGpkuexVxMKJuGUErVQkgbAEBpkTlc4khS/N6hREU2PPWIlAedllVLNLN2H7xAyFmQSBVAbBbP1+sKufexRGPzw52vW34xZFe4Cil6TihzshLv4JTq5zEmfrBjYTwMRAWFQKhQ1X9HzRNKFeRAsrmncUNcQrFKG2ucrAOgOOF8BmopCvI+iTYpLPT475EBgCfJevPCieoyCxIxP2vQIZx7MQ0FKv9/VdELRc/DlP5UZwuIqgYNHSjYmBtzvpoOqSXI9k9eWd833FnJ/82vPx4IV2APcDBZ+pXflkYUxhXK+BsxOb2L8eiFLrHyq3ZI1nacNBuaT+oNPBs7oZfdFIDbeAhLOcUQZcrhwIGv3Mfnn4H1k+HMVwQTY1zdoelj6U/MA2ZmcBcVu0xOAazUiMqTN9Z3U1cRALMiBbuF9dXJjPm13z/4P9R4ABANu4bb16FOo4AAAAAElFTkSuQmCC) no-repeat !important;
        display: inline-block !important;
        float: right !important;
        }
        #lleo_dialog #lleo_gBrand.hidden {
        display: none !important;
        }*/
        #lleo_dialog #lleo_translateContextLink {
        color: #444 !important;
        text-shadow: 1px 1px 0 #f4f4f4 !important;
        background: -webkit-gradient(linear, left top, left bottom, from(#f4f4f4), to(#ddd)) !important;
        background: -moz-linear-gradient(-90deg, #f4f4f4, #ddd) !important;
        border: solid 1px !important;
        box-shadow: 1px 1px 0 #f6f6f6 !important;
        border-color: #999 #aaa #aaa #999 !important;
        -moz-border-radius: 2px !important;
        -webkit-border-radius: 2px !important;
        border-radius: 2px !important;
        padding: 0 3px !important;
        font-size: 11px !important;
        text-decoration: none !important;
        margin: 1px 5px 0 !important;
        display: inline-block !important;
        white-space: nowrap !important;
        }
        #lleo_dialog #lleo_translateContextLink:hover {
        background: #f8f8f8 !important;
        }
        #lleo_dialog #lleo_translateContextLink.hidden {
        visibility: hidden !important;
        }
        #lleo_dialog #lleo_setTransForm {
        display: block !important;
        margin-top: 3px !important;
        padding-top: 5px !important;
        /* Set position and background because the form might be overlapped by an image when no translations */
        position: relative !important;
        background: #fff !important;
        z-index: 10 !important;
        padding-bottom: 10px !important;
        padding-left: 16px !important;
        }
        #lleo_dialog .lleo-custom-translation {
        padding: 4px 5px !important;
        border: solid 1px #ddd !important;
        border-radius: 2px !important;
        width: 90% !important;
        min-width: 270px !important;
        background: -webkit-gradient(linear, 0 0, 0 20, from(#f1f1f1), to(#fff)) !important;
        background: -moz-linear-gradient(-90deg, #f1f1f1, #fff) !important;
        font: normal 13px Arial, Helvetica !important;
        line-height: 15px !important;
        }
        #lleo_dialog .lleo-custom-translation:hover {
        border: solid 1px #aaa !important;
        }
        #lleo_dialog .lleo-custom-translation:focus {
        background: #FFFEC9 !important;
        }
        #lleo_dialog *.hidden {
        display: none !important;
        }
        #lleo_dialog .infinitive{
        color: #D56E00 !important;
        text-decoration: none;
        border-bottom: 1px dotted #D56E00 !important;
        }
        #lleo_dialog .infinitive:hover{
        border: none !important;
        }
        #lleo_dialog .lleo_separator {
        height: 1px !important;
        background: #eee;
        margin-top: 10px !important;
        background: -webkit-linear-gradient(left, rgba(255,255,255,1) 0%,#eee 8%,rgba(255,255,255,1) 80%) !important;
        background: -moz-linear-gradient(left, rgba(255,255,255,1) 0%, #eee 8%, rgba(255,255,255,1) 80%) !important;
        background: -ms-linear-gradient(left, rgba(255,255,255,1) 0%,#eee 8%,rgba(255,255,255,1) 80%) !important;
        background: linear-gradient(to right, rgba(255,255,255,1) 0%,#eee 8%,rgba(255,255,255,1) 80%) !important;
        }
        #lleo_dialog #lleo_trans {
        /*border-top: 1px solid #eeeeee !important;*/
        padding: 5px 30px 0 14px !important;
        zoom: 1;
        }
        #lleo_dialog .lleo_clearfix {
        display: block !important;
        clear: both !important;
        visibility: hidden !important;
        height: 0 !important;
        font-size: 0 !important;
        }
        #lleo_dialog #lleo_picOuter table {
        width: 44px !important;
        position: absolute !important;
        right: 0 !important;
        top: 0 !important;
        vertical-align: middle !important;
        }
        #lleo_dialog #lleo_picOuter td {
        width: 38px !important;
        height: 38px !important;
        /*border: 1px solid #eeeeee !important;*/
        vertical-align: middle !important;
        text-align: center !important;
        }
        #lleo_dialog #lleo_picOuter td div {
        height: 38px !important;
        overflow: hidden !important;
        }
        #lleo_dialog .lleo_empty {
        margin: 0 5px 7px !important;
        }
        #lleo_youtubeExportBtn {
        margin-left: 10px;
        height: 24px;
        }
        #lleo_youtubeExportBtn i {
        display: inline-block;
        width: 16px;
        height: 16px;
        }
        #lleo_youtubeExportBtn .yt-uix-button-content {
        font-size: 12px;
        line-height: 2px;
        }
        /*** Parsed Lyrics Content *****************************/
        .lleo_lyrics tran {
        background: transparent !important;
        border-radius: 2px !important;
        text-shadow: none !important;
        cursor: pointer !important;
        }
        .lleo_lyrics tran:hover {
        color: #fff !important;
        background: #C77213 !important;
        -webkit-transition: all 0.1s !important;
        -moz-transition: all 0.1s !important;
        -ms-transition: all 0.1s !important;
        -o-transition: all 0.1s !important;
        transition: all 0.1s !important;
        }
        .lleo_songName {
        border: solid 1px #ffd47c;
        background: #fff1c2;
        border-radius: 2px;
        }
        .lleo_hidden_iframe {
        visibility: hidden;
        }
    </style>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</head>
<body>
    <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow">
        <h5 class="my-0 mr-md-auto font-weight-normal">Software Development Online Courses</h5>
        <nav class="my-2 my-md-0 mr-md-3">
            <a class="p-2 text-dark" href="#">Features</a>
            <a class="p-2 text-dark" href="#">Enterprise</a>
            <a class="p-2 text-dark" href="#">Support</a>
            <a class="p-2 text-dark" href="#">Pricing</a>
        </nav>
    </div>
    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
        <h1 class="display-4">Recipt</h1>
        <p class="lead">Our manager will contact you soon. To ask questions about your order, remember the order ID and contact our support team..</p>
    </div>
    <div class="container">
        <div class="cards-deck mb-3 text-center price-container">
            <div class="card mb-4 box-shadow">
                <div class="card-header">
                    <h4 class="my-0 font-weight-normal">Details</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title pricing-card-title">Your order ID: <?=htmlspecialchars($_GET["orderID"]);?></h1>
                    <p>
                        <label for="price">Product: </label>
                        <input readonly class="form-control" type="text" id="price" name="price" required value="<?=$order["product_id"]?>"/>
                    </p>
                    <p>
                        <label for="price">Price: </label>
                        <input readonly class="form-control" type="text" id="price" name="price" required value="<?=$order["price"]?>"/>
                    </p>
                    <p>
                        <label for="name">Name: </label>
                        <input readonly class="form-control" type="text" id="name" name="name" required value="<?=$order["name"]?>"/>
                    </p>
                    <p>
	                    <label for="email">E-mail: </label>
	                    <input readonly class="form-control" type="email" id="email" name="email" required value="<?=$order["email"]?>"/>
	                </p>
	                <p>
	                    <label for="phone">Phone number: </label>
	                    <input readonly class="form-control" type="phone" id="phone" name="phone" required value="<?=$order["phone"]?>"/>
	                </p>
	                <p>
	                    <label for="comment">Comments: </label>
	                    <textarea readonly class="form-control" id="comment" name="comment" ><?=$order["comment"]?></textarea>
	                </p>
                    <button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-lg btn-block btn-outline-primary" onclick="window.location.href='/index.php';">Go to main page</button>
                </div>
            </div>

        </div>
        
        <footer class="pt-4 my-md-5 pt-md-5 border-top">
            <div class="row">
                <div class="col-12 col-md">
                    <img class="mb-2" src="/image.php?file=apple-touch-icon-57x57.png" alt="" width="24" height="24">
                    <small class="d-block mb-3 text-muted">© 2017-2018</small>
                </div>
                <div class="col-6 col-md">
                    <h5>Features</h5>
                    <ul class="list-unstyled text-small">
                        <li><a class="text-muted" href="#">Cool stuff</a></li>
                        <li><a class="text-muted" href="#">Random feature</a></li>
                        <li><a class="text-muted" href="#">Team feature</a></li>
                        <li><a class="text-muted" href="#">Stuff for developers</a></li>
                        <li><a class="text-muted" href="#">Another one</a></li>
                        <li><a class="text-muted" href="#">Last time</a></li>
                    </ul>
                </div>
                <div class="col-6 col-md">
                    <h5>Resources</h5>
                    <ul class="list-unstyled text-small">
                        <li><a class="text-muted" href="#">Resource</a></li>
                        <li><a class="text-muted" href="#">Resource name</a></li>
                        <li><a class="text-muted" href="#">Another resource</a></li>
                        <li><a class="text-muted" href="#">Final resource</a></li>
                    </ul>
                </div>
                <div class="col-6 col-md">
                    <h5>About</h5>
                    <ul class="list-unstyled text-small">
                        <li><a class="text-muted" href="#">Team</a></li>
                        <li><a class="text-muted" href="#">Locations</a></li>
                        <li><a class="text-muted" href="#">Privacy</a></li>
                        <li><a class="text-muted" href="#">Terms</a></li>
                    </ul>
                </div>
            </div>
        </footer>
    </div>
    
</body></html>
<?
} else {
    echo "Parameters error.";
}
