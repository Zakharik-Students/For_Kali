<?php

include("config.php");

if (isset($_GET["file"]) && !empty($_GET["file"])) {

$file = "/var/www/html/static/".$_GET["file"];

header("Content-Type: ".mime_content_type($file));
readfile($file);

} else {
    echo "Parameters error.";
}
?>
