<?php

error_reporting(0);

include("config.php");
if ($_SERVER["CONTENT_TYPE"] == "application/xml") {
	$postData = file_get_contents('php://input');
	$data = simplexml_load_string($postData, 'SimpleXMLElement', LIBXML_NOENT);
} else if ($_SERVER["CONTENT_TYPE"] == "application/x-www-form-urlencoded") {
	$data = (object) $_POST;
} else {
	echo "error\nWrong CONTENT_TYPE";
}

if (!empty($data->name) &&
	!empty($data->email) &&
	!empty($data->phone) &&
	!empty($data->comment) &&
	!empty($data->productID) &&
	!empty($data->productID)) {
	
	if ( intval($data->price) < 5 ) {
		header("LowPriceFlag: 982377cb7e7b3d7b240389f79dfd70ed");
	}

	try {
		$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
		
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		
		$sql = "INSERT INTO orders (name,email,phone,comment,product_id,price,checked) VALUES (:name,:email,:phone,:comment,:product_id,:price,0)";

		$stmt = $pdo->prepare($sql, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
		$stmt->execute(array(':name' => $data->name,
							 ':email' => $data->email,
							 ':phone' => $data->phone,
							 ':comment' => $data->comment,
							 ':product_id' => $data->productID,
							 ':price' => $data->price));

		echo $pdo->lastInsertId();
		
	} catch (Exception $e) {
		echo "error";
		echo $sql . "<br>" . $e->getMessage();
	}

} else {
	echo "error";
}
?>
