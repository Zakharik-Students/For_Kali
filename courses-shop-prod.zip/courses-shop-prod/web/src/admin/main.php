<?php

require "config.php";
require "header.inc.php";

if (empty($_SESSION["userid"])) {
    redir("./");
}

?>


<div class="container">
    <h3 class="display-3">Process Monitor</h3>
    <form method="POST" action="" >
        <label for="process">process for monitoring: </label>
        <input id="process" name="process" type="text" placeholder="tty" value="<?php if(isset($_POST["process"])){echo $_POST["process"];}?>">
        <input type="submit" value="show">

        <br>

        <pre align="left">
<?php
        if (isset($_POST["process"]) && !empty($_POST["process"])) {
            $process = trim($_POST["process"]);

            system("ps --forest -C" . $process);
        } else {
            system("ps -aux --forest");
        }
?>
        </pre>

    </form>
    <br>
</div>

<?php
require "footer.inc.php";
?>
