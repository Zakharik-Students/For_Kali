<?php

require "config.php";
require "header.inc.php";

if (!empty($_SESSION["otp"]) && $_SESSION["otp"] === 1 ) {
    redir("./main.php");
} else if (!empty($_SESSION["userid"]) && $_SESSION["userid"] === "admin" ) {
    redir("./otp.php");
} else if (isset($_POST['password'])) {

$username = strtolower(trim(@$_POST['username']));
$password = trim(@$_POST['password']);

if ($username === "admin" && password_verify($password,"$2y$10$8kDC3tJbzljjrcvHWlPXDeSvdInyCD1cRhTaoQFUNe5UbTrHf8she")) {
    $_SESSION["userid"] = "admin";
    $_SESSION["secret"] = sprintf("%03d", rand(0,999));
    $_SESSION["otp"] = 0;
    redir("otp.php");

} else {
    $error = true;
}
}
?>

<form class="form-signin" method="POST">
    <h1 class="h3 mb-3 font-weight-normal">Admin panel</h1>
    <?php
    if (isset($error) && $error){ echo '<div class="error" style="color: red; margin: 10px 0;"><p>Wrong password. Try again.</p></div>'; }?>
    <div style="margin: 10px 0;">
	    <label for="inputEmail" class="sr-only">Email address</label>
	    <input type="text" id="username" class="form-control" placeholder="Username" required="" autofocus="" name="username">
	</div>
    <div>
    	<label for="inputPassword" class="sr-only">Password</label>
    	<input type="password" id="password" class="form-control" placeholder="Password" required="" name="password">
    </div>
    <button class="btn btn-lg btn-primary btn-block" type="submit">Login</button>
</form>

<?php
require "footer.inc.php";
?>