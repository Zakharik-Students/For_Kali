<?php

require "config.php";
require "header.inc.php";

if (empty($_SESSION["userid"]) || $_SESSION["userid"] !== "admin" ) {
    redir("./index.php");
}
echo "<!-- ";
var_dump($_SESSION);
echo " -->";

if (empty($_SESSION["otp"]) && $_SESSION["otp"] !== 0) {
    redir("./index.php");
}

if (!empty($_SESSION["otp"]) && $_SESSION["otp"] === 1) {
    redir("./main.php");
}

$otp = strtolower(trim(@$_POST['OTP']));

if ($_SESSION["userid"] === "admin" && $_SESSION["secret"] === $otp) {
    $_SESSION["otp"] = 1;
    redir("main.php");

}
?>

<form class="form-signin" method="POST">
    <h1 class="h3 mb-3 font-weight-normal">Second factor authentication</h1>
    <div style="margin: 10px 0;">
        <label for="inputOTP" class="sr-only">OTP</label>
        <input type="OTP" id="OTP" class="form-control" placeholder="OTP" required="" name="OTP">
    </div>
    <button class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
</form>

<?php
require "footer.inc.php";
?>