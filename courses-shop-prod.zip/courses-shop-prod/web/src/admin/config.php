<?php
ob_start();
session_start();

function redir($url) {
    header("Location: $url", true, 303);
    ob_end_clean();
    exit;
}

?>
