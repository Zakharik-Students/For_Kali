#!/bin/bash
. /opt/script-bot.sh

sleep 15

python3 -u /opt/supbot/bot.py
